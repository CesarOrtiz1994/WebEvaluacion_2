package com.idgs06.UTEQLive.publication.repository;

import com.idgs06.UTEQLive.publication.entity.Imagen;
import org.springframework.data.jpa.repository.JpaRepository;


public interface IImagenRepository extends JpaRepository<Imagen, Integer>{

}
