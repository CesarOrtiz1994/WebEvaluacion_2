package com.idgs06.UTEQLive.publication.repository;

import com.idgs06.UTEQLive.publication.entity.Comentario;
import org.springframework.data.jpa.repository.JpaRepository;


public interface IComentarioRepository extends JpaRepository<Comentario, Integer>{

}
